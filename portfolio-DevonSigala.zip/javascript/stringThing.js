function setup() {
  background(0);
	textFont('monospace');
   var canvas=createCanvas(500, 200);
	textAlign(CENTER);
	fill(255,0,0);
	textSize(30);
	text("This is a Haiku",200,30);
	fill(255);
	text("This is still a Haiku. And",225,75);
	fill(0,0,255);
	text("This is the last line",200,120);
}

function draw() {
	
}